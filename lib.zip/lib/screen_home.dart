import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';



class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);



  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

   late List<charts.Series<Task,String>> _seriesPieData;
   late List<charts.Series<Pollution,String>> _seriesData;
   late List<charts.Series<Sales,int>> _seriesLineData;


   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _generateData();
    List<charts.Series<Task,String>>()= _seriesPieData;
    List<charts.Series<Pollution,String>>()= _seriesData;
    List<charts.Series<Sales,int>>()= _seriesLineData;
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            bottom: TabBar(
              indicatorColor: Colors.cyan,
              tabs: [
                Tab(
                icon: Icon(FontAwesomeIcons.chartPie),
                ),
                Tab(
                icon: Icon(FontAwesomeIcons.chartPie),
                ),
                Tab(
                icon: Icon(FontAwesomeIcons.chartPie),
                ),

              ],

            ),
            title: Text("Flutter Charts"),
          ),
          body: TabBarView(
            children: [
              Padding(padding: EdgeInsets.all(8.0),
                child: Container(
                  child: Center(
                    child: Column(
                      children: <Widget>[
                        Text('Sales for the first 5 years',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10,),
                        Expanded(
                            child: charts.LineChart(
                              _seriesLineData,
                              defaultRenderer: new charts.LineRendererConfig(
                                includeArea: true, stacked: true
                              ),
                              animate: true,
                              animationDuration: Duration(seconds: 5),
                              behaviors: [
                              new charts.ChartTitle(
                                'Years',
                                behaviorPosition: charts.BehaviorPosition.bottom,
                                titleOutsideJustification: charts.OutsideJustification.middleDrawArea,
                              ),
                                new charts.ChartTitle(
                                  'Sales',
                                  behaviorPosition: charts.BehaviorPosition.end,
                                  titleOutsideJustification: charts.OutsideJustification.middleDrawArea,
                                ),
                              ],

                            )


                        )
                      ],
                    ),
                  ),

                ),
              ),
              Padding(padding: EdgeInsets.all(8.0),
              child: Container(
                child: Center(
                  child: Column(
                    children: <Widget>[
                      Text('Time spent on daily task',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10,),
                      Expanded(
                          child: charts.PieChart(
                            _seriesPieData,
                            animate: true,
                            animationDuration: Duration(seconds: 5),
                            behaviors: [
                              new charts.DatumLegend(
                                outsideJustification: charts.OutsideJustification.endDrawArea,
                                horizontalFirst: false,
                                desiredMaxRows: 2,
                                cellPadding: new EdgeInsets.only(right: 4,bottom: 4),
                                entryTextStyle: charts.TextStyleSpec(
                                  color: charts.MaterialPalette.purple.shadeDefault,
                                  fontFamily: 'Georgia',
                                  fontSize: 11,
                                )
                              )
                            ],
                            defaultRenderer: new charts.ArcRendererConfig(
                              arcWidth: 100,
                              arcRendererDecorators: [
                                new charts.ArcLabelDecorator(
                                  labelPosition: charts.ArcLabelPosition.inside,
                                )
                              ]
                            ),

                          )


                      )
                    ],
                  ),
                ),

              ),
              ),
              Padding(padding: EdgeInsets.all(8.0),
              child: Container(
                child: Center(
                  child: Column(
                    children: <Widget>[
                      Text('CO2 emission by world region.',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10,),
                      Expanded(
                          child: charts.BarChart(
                            _seriesData,
                            animate: true,
                            barGroupingType: charts.BarGroupingType.grouped,
                            animationDuration: Duration(seconds: 5),


                          )


                      )
                    ],
                  ),
                ),

              ),
              )

            ],
          ),
        ),
      ),
    );

  }

  void _generateData() {

    var data1=[
      new Pollution(1980,'USA',30),
      new Pollution(1980,'Asia',40),
      new Pollution(1980,'Europe',20),
    ];
    var data2=[
      new Pollution(1980,'USA',100),
      new Pollution(1980,'Asia',150),
      new Pollution(1980,'Europe',80),
    ];
    var data3=[
      new Pollution(1980,'USA',200),
      new Pollution(1980,'Asia',250),
      new Pollution(1980,'Europe',180),
    ];

    var linesalesdata1=[
      new Sales(0, 23),
      new Sales(1, 33),
      new Sales(2, 43),
      new Sales(3, 53),
      new Sales(4, 63),
    ];var linesalesdata2=[
      new Sales(0, 231),
      new Sales(1, 332),
      new Sales(2, 433),
      new Sales(3, 534),
      new Sales(4, 635),
    ];var linesalesdata3=[
      new Sales(0, 131),
      new Sales(1, 132),
      new Sales(2, 133),
      new Sales(3, 134),
      new Sales(4, 135),
    ];


    _seriesLineData.add(
        charts.Series(
          data: linesalesdata1,
          domainFn: (Sales sales, _) => sales.yearinterval,
          measureFn: (Sales sales, _) => sales.salesval,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          colorFn: (_,__)=>charts.ColorUtil.fromDartColor(Color(0xf754435)),
          id: '2021',
        )
    );
    _seriesLineData.add(
        charts.Series(
          data: linesalesdata2,
          domainFn: (Sales sales, _) => sales.yearinterval,
          measureFn: (Sales sales, _) => sales.salesval,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          colorFn: (_,__)=>charts.ColorUtil.fromDartColor(Color(0xf98435)),
          id: '2022',
        )
    );
    _seriesLineData.add(
        charts.Series(
          data: linesalesdata3,
          domainFn: (Sales sales, _) => sales.yearinterval,
          measureFn: (Sales sales, _) => sales.salesval,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          colorFn: (_,__)=>charts.ColorUtil.fromDartColor(Color(0xff87435)),
          id: '2023',
        )
    );






    _seriesData.add(
        charts.Series(
          data: data1,
          domainFn: (Pollution pollution, _) => pollution.space,
          measureFn: (Pollution pollution, _) => pollution.quantity,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          fillColorFn: (Pollution pollution,_)=>
              charts.ColorUtil.fromDartColor(Color(0xf9423525)),
          id: '2017',
        )
    );
    _seriesData.add(
        charts.Series(
          data: data2,
          domainFn: (Pollution pollution, _) => pollution.space,
          measureFn: (Pollution pollution, _) => pollution.quantity,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          fillColorFn: (Pollution pollution,_)=>
              charts.ColorUtil.fromDartColor(Color(0xf546463)),
          id: '2018',
        )
    );
    _seriesData.add(
        charts.Series(
          data: data3,
          domainFn: (Pollution pollution, _) => pollution.space,
          measureFn: (Pollution pollution, _) => pollution.quantity,
          fillPatternFn: (_,__)=>charts.FillPatternType.solid,
          fillColorFn: (Pollution pollution,_)=>
              charts.ColorUtil.fromDartColor(Color(0xf345535)),
          id: '2019',
        )
    );



    var pieData=[
      new Task('work',324.43,Colors.brown),
      new Task('commute',443.43,Colors.black),
      new Task('eat',4243.43,Colors.teal),
      new Task('sleep',234.43,Colors.lightBlue),
      new Task('other',23.43,Colors.yellow),

    ];

    _seriesPieData.add(
     charts.Series(
       data: pieData,
       domainFn: (Task task, _) => task.task,
       measureFn: (Task task, _) => task.taskValue,
       colorFn: (Task task,_)=>
           charts.ColorUtil.fromDartColor(task.colorval),
       id: 'Daily Task',
       labelAccessorFn: (Task row,_)=>'${row.taskValue}',
     )
    );
  }
}

class Task{
  String task;
  double taskValue;
  Color colorval;

  Task(this.task, this.taskValue, this.colorval);
}
class Pollution{
  String space;
  int year;
  int quantity;

  Pollution(this.year,this.space,  this.quantity);
}
class Sales{
  int yearinterval;
  int salesval;

  Sales(this.yearinterval,this.salesval);
}





